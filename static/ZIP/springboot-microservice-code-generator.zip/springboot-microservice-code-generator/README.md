# springboot-microservice-code-generator
-----------------
springboot-microservice-code-generator is an extension of spring initializer that acts as a scaffholding project to generate spring boot based application based on the template type.

## Template Types: 

1. CRUD-Repository
2. JPA-Repository
3. RabbitMQ
4. Apache Kafka
5. Spring-Integration-with-HTTP
6. Spring-Integration-with-Rabbit
7. Spring-Multitenancy

