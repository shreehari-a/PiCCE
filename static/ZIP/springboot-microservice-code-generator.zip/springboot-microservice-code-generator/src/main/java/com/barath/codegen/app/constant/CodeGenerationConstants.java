package com.barath.codegen.app.constant;

public class CodeGenerationConstants {
	
	public static final String METADATA_FOLDER=System.getProperty("user.dir")+"/src/main/resources/metadata";
	public static final String JSON_EXTENSION=".json";

}
